package org.catalogic.exceptions;

public class CatalogException extends Exception {
    public CatalogException(String message) {
        super(message);
    }
}
