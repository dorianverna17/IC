package org.catalogic;

public class Test4 {

    /*
     * For the final test, lets make sure that we can add a grade for a student.
     *
     * == TASK_9 == : run tests with coverage. Make coverage 100% by adding in this class all the tests needed.
     *
     * */

}
