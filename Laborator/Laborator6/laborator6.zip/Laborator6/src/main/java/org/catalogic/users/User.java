package org.catalogic.users;

public interface User {
}
