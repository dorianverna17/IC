package TestingModule;

import Code.Calculator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestingFile {
    @Test
    public void getTotalAmountWithZeroTips() {
        Calculator calculator = new Calculator();
        assertEquals(10, calculator.calculate(10, 0));
    }

    @Test
    public void getTotalAmountWithTips() {
        Calculator calculator = new Calculator();
        assertEquals(85.8, calculator.calculate(78, 10));
    }

    @ParameterizedTest
    @ValueSource(doubles = {0, 10, 100, 78, 20})
    public void getTotalAmountWithTips2(Double amount) {
        Calculator calculator = new Calculator();
        System.out.println("Amount " + amount + " with tips 10 = " + calculator.calculate(amount, 10));
    }

    @ParameterizedTest
    @CsvSource({
            "0, 0",
            "10, 11",
            "100, 110",
            "78, 85.8",
            "20, 22",
    })
    public void getTotalAmountWithTips3(Double amount, Double expected) {
        Calculator calculator = new Calculator();
        assertEquals(expected, calculator.calculate(amount, 10));
    }
}
