package org.catalogic.constants;

public enum UserType {
    STUDENT,
    TEACHER
}
