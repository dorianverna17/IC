package org.catalogic;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Test3 {

    /*
     * For the third test, lets make sure that we can add a grade for a student.
     *
     * == TASK_4 == : Write the test for adding a VALID grade for an EXISTING student for Laboratory no. 6.
     *
     * == TASK_5 == : Write the test for adding an INVALID grade (<0 or >10) for an EXISTING student for Laboratory no. 6.
     *
     * == TASK_6 == : Write the test for adding a VALID grade for an NON-EXISTING student for Laboratory no. 6.
     *
     * == TASK_7 == : Write the test for adding a VALID grade for an EXISTING student for a Laboratory out of bounds (>12).
     *
     * == TASK_8 == : Write the test for adding a VALID grade for an EXISTING student for Laboratory no. 6 when it was
     * already graded.
     *
     * */

    @BeforeEach
    void setUp() {
        /* I might be useful. */
    }

    /* TASk_4 */
    @Test
    void addGrade_ValidInput_PositiveScenario() {
        /* IF I PASS, YOU PASS */
    }

    /* TASk_5 */
    @Test
    void addGrade_InvalidGrade_ThrowsCatalogException() {
        /* IF I PASS, YOU PASS */
    }

    /* TASk_6 */
    @Test
    void addGrade_InvalidStudent_ThrowsCatalogException() {
        /* IF I PASS, YOU PASS */
    }

    /* TASk_7 */
    @Test
    void addGrade_InvalidLaboratory_ThrowsCatalogException() {
        /* IF I PASS, YOU PASS */
    }

    /* TASk_8 */
    @Test
    void addGrade_AlreadyGraded_ThrowsCatalogException() {
        /* IF I PASS, YOU PASS */
    }

}
