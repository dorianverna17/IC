class Node {
    int value;
    Node nextNode;

    public Node(int value) {
        this.value = value;
    }
}