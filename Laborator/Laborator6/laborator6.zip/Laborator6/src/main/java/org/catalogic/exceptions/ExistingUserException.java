package org.catalogic.exceptions;

public class ExistingUserException extends CatalogException {
    public ExistingUserException(String message) {
        super(message);
    }
}
