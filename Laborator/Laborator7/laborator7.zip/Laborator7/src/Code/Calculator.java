package Code;

public class Calculator {
    public double calculate(double amount, double tips) {
        var tipsAmount = amount / 100 * tips;
        return amount + tipsAmount;
    }
}
